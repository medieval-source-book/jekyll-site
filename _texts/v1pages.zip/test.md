---
layout: text
sidebar: left
title: |
  TEST | TEST
engtitle: |
  TEST
origtitle: |
  TEST
breadcrumb: true
permalink: "text/test"
identifier: "test"
textauthor: Test
languages: [English, Western Europe]
periods: [7th Century]
genres: [Exemplum]
textcollections: []
sdr: https://library.stanford.edu/research/stanford-digital-repository 
doi: example-doi 
image: /assets/img/text/test.jpg
thumb: /assets/img/text/test-thumb.jpg
imagesource: |
  TEST
fulltext: |
    戀の心を On the topic of love. さても我が思ふ思よ遂にいかに何のかひなき詠のみして Well, well, here I am,so many feelings I feel!What will become of them,with this good-for-nothinggaze I keep giving my thoughts? 
---
## Credits
Text based on 二十一代集 第8 (Twenty One Imperial Collections, Vol. 8); Taiyōsha; Date published: 1925, 
Translation by Scott Stevens, 
Encoded in TEI P5 XML by Danny Smith
## Suggested Citation
<p>Suggested citation: Test.  "TEST."  <em>Global Medieval Sourcebook</em>. <a href="http://sourcebook.stanford.edu/text/test">http://sourcebook.stanford.edu/text/test</a>. Retrieved on February 03, 2021.</p>